# Hakkani Medical center 

This project was bootstrapped with
Live Link :https://hakkani-medical-center.web.app/
## Our Services 

* Extra Care To Our Patients
* Discount to poor and free to parentless people
* Ambulance Caring is Totally free
* Open in 24/7 Hours 
* Hospital is clean and Save

## Our Machanaries

 * High Quality Xray Machine
 * Lab Report is 100% Right
 * qualified Doctors
 * Some Special Doctors ()
